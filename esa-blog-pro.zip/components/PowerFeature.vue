<template>
  <div class="card card-hover p-8 text-center group">
    <div class="flex justify-center mb-6">
      <div 
        class="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 transform group-hover:scale-110"
        :class="`bg-gradient-to-r ${gradient}`"
      >
        <component :is="icon" class="w-8 h-8 text-white" />
      </div>
    </div>
    <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4 group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors duration-300">
      {{ title }}
    </h3>
    <p class="text-gray-600 dark:text-gray-300 leading-relaxed">
      {{ description }}
    </p>
  </div>
</template>

<script setup lang="ts">
interface Props {
  icon: any
  title: string
  description: string
  gradient: string
}

defineProps<Props>()
</script>
